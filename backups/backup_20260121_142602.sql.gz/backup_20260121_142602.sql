--
-- PostgreSQL database dump
--

\restrict 364UXODAA4AoJ8eCHq5eSKX9HZ7EJY3cqss3xnk6QC3gwKc6nTfNVSfBEIH3B99

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: family_members; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.family_members (
    id text NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.family_members OWNER TO admin;

--
-- Name: households; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.households (
    id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.households OWNER TO admin;

--
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.push_subscriptions (
    id uuid NOT NULL,
    household_id uuid NOT NULL,
    family_member_id text,
    endpoint text NOT NULL,
    keys jsonb NOT NULL,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.push_subscriptions OWNER TO admin;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    title text NOT NULL,
    date date NOT NULL,
    time_label text,
    priority text NOT NULL,
    recurrence text,
    description text,
    assignees jsonb NOT NULL,
    series_id text,
    days_of_week integer[],
    duration_weeks integer,
    notification_time integer,
    color text,
    notification_sent boolean DEFAULT false,
    end_date date,
    is_completed boolean DEFAULT false,
    created_by text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tasks OWNER TO admin;

--
-- Data for Name: family_members; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.family_members (id, household_id, name, color, created_at) FROM stdin;
mama	00000000-0000-0000-0000-000000000000	Maria	#f97316	2025-12-03 21:08:48.955493+00
papa	00000000-0000-0000-0000-000000000000	Alvaro	#22c55e	2025-12-03 21:08:48.960593+00
familia	00000000-0000-0000-0000-000000000000	Todos	#6366f1	2025-12-03 21:08:48.964398+00
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.households (id, name, created_at) FROM stdin;
00000000-0000-0000-0000-000000000000	Familia Barcelona	2025-12-03 21:08:48.950403+00
\.


--
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.push_subscriptions (id, household_id, family_member_id, endpoint, keys, user_agent, created_at, last_used_at, is_active) FROM stdin;
73d2b8c5-59b4-4d2e-8535-ea552167e542	00000000-0000-0000-0000-000000000000	\N	https://fcm.googleapis.com/fcm/send/cs1pshdHiXk:APA91bFuHYipK2bhHO0vUPjQ03YZbBpB2-Xr82HLz8e7gkXYNdbJEwGX2j41RMFJALWz-huBe45MMJurESoU-BvE2heWFnHaElWXnDpmgutYd7amAipYwNk1Ctr8mlE-q8APton8THXZ	{"auth": "7KrORWTfq2EHv-vKERqBMw", "p256dh": "BJBs8r1Vim2R3EehmlJfxtZEC4c_0qvXDoNUDUsevXzH7QHwtdUj8ZmbKORs9WAceb3tCXbiHkIA0r5ImqXSx0I"}	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	2025-12-03 21:37:16.701638+00	\N	t
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.tasks (id, title, date, time_label, priority, recurrence, description, assignees, series_id, days_of_week, duration_weeks, notification_time, color, notification_sent, end_date, is_completed, created_by, created_at) FROM stdin;
40221ac2-89d0-47a7-b04b-5aa7ac65a296	test created by	2025-12-08	13:51	MEDIUM	NONE	\N	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	\N	\N	f	\N	f	Alvaro	2025-12-08 11:50:12.941159+00
7693aecf-feaf-475f-8bc0-eda62ca5a9ee	werewr	2025-12-09	\N	MEDIUM	NONE	werw	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	\N	\N	f	\N	t	Alvaro	2025-12-09 22:31:45.119835+00
435c4dcc-4953-4e66-82c1-6e42c9e03ae0	ertzert	2025-12-09	\N	MEDIUM	NONE	\N	[{"id": "familia", "name": "Familia", "color": "#6366f1"}]	\N	\N	\N	\N	\N	f	\N	f	Maria	2025-12-09 22:36:07.352503+00
f753c5e4-1c4e-44a9-af19-996528ce5108	test local notificación 10 min	2025-12-03	22:57	MEDIUM	NONE	\N	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	10	#f97316	t	\N	f	\N	2025-12-08 11:48:04.650516+00
48f76ba9-c790-49a0-8bcb-912f2616c15a	test local notificación 10 min	2025-12-03	22:58	MEDIUM	NONE	\N	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	10	#f97316	t	\N	f	\N	2025-12-08 11:48:04.650516+00
4335609f-7a4f-4869-8390-d397121f4aec	test local	2025-12-04	22:50	HIGH	NONE	\N	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	10	#f97316	f	\N	f	\N	2025-12-08 11:48:04.650516+00
4bc05876-fec1-4f44-a513-a66978880457	test local	2025-12-04	17:24	MEDIUM	NONE	asdasd	[{"id": "familia", "name": "Todos", "color": "#6366f1"}]	\N	\N	\N	\N	#22c55e	f	\N	f	\N	2025-12-08 11:48:04.650516+00
e942e566-05b1-4a9f-bed9-c53cf6e4aa2b	test local notificación 10 min	2025-12-04	23:10	MEDIUM	NONE	\N	[{"id": "papa", "name": "Alvaro", "color": "#22c55e"}]	\N	\N	\N	10	#ef4444	t	\N	f	\N	2025-12-08 11:48:04.650516+00
\.


--
-- Name: family_members family_members_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.family_members
    ADD CONSTRAINT family_members_pkey PRIMARY KEY (id);


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_pkey PRIMARY KEY (id);


--
-- Name: push_subscriptions push_subscriptions_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_endpoint_key UNIQUE (endpoint);


--
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: family_members family_members_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.family_members
    ADD CONSTRAINT family_members_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id);


--
-- Name: push_subscriptions push_subscriptions_family_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_family_member_id_fkey FOREIGN KEY (family_member_id) REFERENCES public.family_members(id);


--
-- Name: push_subscriptions push_subscriptions_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 364UXODAA4AoJ8eCHq5eSKX9HZ7EJY3cqss3xnk6QC3gwKc6nTfNVSfBEIH3B99

